﻿using UnityEngine;
using System.Collections;

namespace MLPlayer {
	public class Defs {
		public static string PLAYER_TAG = "Player";
		public static string PLAYER = "FPSController";
		public static string LANDMARK = "landmark";
	}
}