﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System;
namespace MLPlayer {
public class OmniCam : MonoBehaviour {
		public SceneController sc;
		public float[][] foods;
		public float[][] agents;
		public float[] nest;
		// Use this for initialization
		void Start () {
			foods = new float[sc.yellowstuff.Count][];
			agents = new float[sc.agents.Count][];
			for (int i = 0; i < sc.yellowstuff.Count; i++) {
				foods [i] = new float[3];
			}
			for (int i=0; i < sc.agents.Count ; i++){
				agents [i] = new float[3];
			}
			nest = new float[2];
		}
		float [][] SortFloatList(float [][] src, int len){
			for (int i = 0; i < len; i++) {
				for (int j = 0; j < len - i - 1; j++) {
					if (src [j][2] > src [j + 1][2]) {
						float [] tmp = src [j];
						src [j] = src [j + 1];
						src [j + 1] = tmp;
					}
				}
			}
			return src;
		}

		// Update is called once per frame
		void FixedUpdate () {
			for (int i = 0; i < sc.yellowstuff.Count; i++) {
				Vector3 pos = this.transform.position - sc.yellowstuff [i].transform.position;
				foods [i] [2] = (pos).magnitude;
				foods [i] [0] = pos.x / foods [i] [2];
				foods [i] [1] = pos.y / foods [i] [2];
			}
			foods = SortFloatList (foods, sc.yellowstuff.Count);
			Debug.Log (foods);
			for (int i = 0; i < sc.agents.Count; i++) {
				Vector3 pos = this.transform.position - sc.agents [i].transform.position;
				agents [i] [2] = pos.magnitude+0.001f;
				agents [i] [0] = pos.x / agents [i] [2];
				agents [i] [1] = pos.y / agents [i] [2];
			}
			agents = SortFloatList (agents, sc.agents.Count);
			
			Vector3 dis_nest = this.transform.position - sc.landmarks[0].transform.position;
			//nest [2] = dis_nest.magnitude;
			nest [0] = dis_nest.x / dis_nest.magnitude;
			nest [1] = dis_nest.y / dis_nest.magnitude;
		}

	}
}