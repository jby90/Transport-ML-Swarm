﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


namespace MLPlayer {
	public class State {
		public float[] reward = new float[11];
		public bool endEpisode;
		public byte[][] image;
		public byte[][] depth;
		public int[][] ir;
		public int[][] compass;
		public int[][] ground;
		public int[][] target;
		public float distRecord;
		public int[][] foodornot;
		public float[][] first_food;
		public float[][] second_food;
		public float[][] first_agent;
		public float[][] second_agent;
		public float[][] nest;
		public void Clear() {
			reward = null;
			endEpisode = false;
			image = null;
			depth = null;
			ir = null;
			compass = null;
			ground = null;
			target = null;
			distRecord = 0;
			/*first_food = null;
			second_food = null;
			first_agent = null;
			second_agent = null;
			nest = null;*/
		}
		public void Reset() {
			endEpisode = false;
			image = null;
			depth = null;
			ir = null;
			compass = null;
			ground = null;
			reward [0] = 0;
			/*first_food = null;
			second_food = null;
			first_agent = null;
			second_agent = null;
			nest = null;*/
		}
	}
}