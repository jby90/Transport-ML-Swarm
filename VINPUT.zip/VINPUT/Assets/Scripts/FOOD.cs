﻿using UnityEngine;
using System.Collections.Generic;
using System.Threading;
using MsgPack;

namespace MLPlayer
{
public class FOOD : MonoBehaviour {

		[SerializeField] SceneController sc;
		public Renderer rend;
		public Collider coll;
		public Rigidbody rb;
		private Vector3 area_pos;
		private	Vector3 food_area_dis;
		private float food_area_dis_mag;
		private float food_area_dis_pre;
		private float[] shortest_food_agent_dist;
	// Use this for initialization
	void Start () {
			rend = GetComponent<Renderer> ();
			coll = GetComponent<Collider> ();
			rb = GetComponent<Rigidbody>();
			rend.enabled = true;
			coll.enabled = true;
			food_area_dis_pre = getFoodAreaDist ().magnitude;
			shortest_food_agent_dist = new float[sc.agents.Count];
			for (int i = 0; i < sc.agents.Count; i++) {
				shortest_food_agent_dist [i] = 999;
			}
	}
	public void disableRendAndColl(){
			rend.enabled = false;
			coll.enabled = false;
			rb.constraints = RigidbodyConstraints.FreezeAll;

		}

	public void enableRendandColl(){
			rend.enabled = true;
			coll.enabled = true;
			rb.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
		}
			
	/*public void random(){
			rend.enabled = true;
			coll.enabled = true;
			rb.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
		}*/


		Vector3 getFoodAreaDist (){
			Vector3 dist;
			dist = (gameObject.transform.position - GameObject.FindGameObjectWithTag("AREA").transform.position);
			dist.y = 0;
			return dist;
		}

	public void Reset(){
		food_area_dis_pre = getFoodAreaDist ().magnitude;
		for (int i = 0; i < sc.agents.Count; i++) {
			shortest_food_agent_dist [i] = 999;
		}
	}

		public void calReward(){
			area_pos = GameObject.FindGameObjectWithTag ("AREA").transform.position;

			food_area_dis = gameObject.transform.position - area_pos;
			food_area_dis.y = 0;

			//position.z = 0;
			food_area_dis_mag = food_area_dis.magnitude;
			for (int i = 0; i < sc.agents.Count; i++) {
				float d = (sc.agents [i].transform.position - gameObject.transform.position).magnitude;
				if (d < shortest_food_agent_dist [i]) {
					shortest_food_agent_dist [i] = d;
					//Debug.Log ("agent " + i + " reward: " + sc.agents [i].state.reward [0]);
					if (d > 5) {
						sc.agents [i].state.reward [0] += 0.1f;
						sc.agents [i].state.reward [1] += 0.1f;
						sc.agents [i].state.reward [3] += 0.1f;
						//Debug.Log ("get approach reward " + i);
					}

				}
			}
			if (food_area_dis_mag - food_area_dis_pre < 0) {
				for (int i = 0; i < sc.agents.Count; i++) {
					float dist = (sc.agents [i].transform.position - gameObject.transform.position).magnitude;
					if (dist < 4.6) {


						sc.agents [i].state.reward [0] += 5;
						sc.agents [i].state.reward [1] += 5;
						sc.agents [i].state.reward [2] += 5;

						/*sc.agents [i].state.reward [0] += 36/(food_area_dis_mag*food_area_dis_mag);
						sc.agents [i].state.reward [1] += 36/(food_area_dis_mag*food_area_dis_mag);
						sc.agents [i].state.reward [2] += 36/(food_area_dis_mag*food_area_dis_mag);
						*/

						//Debug.Log ("get push reward " + i);
					}
				}
				food_area_dis_pre = food_area_dis_mag;
			} 
		}

	// Update is called once per frame
	void Update () {
			
			if (food_area_dis_mag < 6) {
				for (int i = 0; i < sc.agents.Count; i++) {
					
						//sc.agents [i].state.reward [0] += 10000;
						//sc.agents [i].state.reward [1] += 10000;
						//sc.agents [i].state.reward [4] += 10000;

				}
				disableRendAndColl ();
			} else {
				enableRendandColl ();
			}
		}
	}
}
	
