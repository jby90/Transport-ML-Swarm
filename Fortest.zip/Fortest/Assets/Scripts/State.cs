﻿using UnityEngine;
using System.Collections;

namespace MLPlayer {
	public class State {
		public float[] reward;
		public bool endEpisode;
		public byte[][] image;
		public byte[][] depth;
		public int[][] ir;
		public int[][] compass;
		public int[][] ground;
		public int[][] target;
		public float distRecord;
		public int[][] foodornot;
		public void Clear() {
			reward = null;
			endEpisode = false;
			image = null;
			depth = null;
			ir = null;
			compass = null;
			ground = null;
			target = null;
			distRecord = 0;
		}
		public void Reset() {
			endEpisode = false;
			image = null;
			depth = null;
			ir = null;
			compass = null;
			ground = null;
		}
	}
}